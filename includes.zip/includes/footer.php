<footer class="main-footer">
    <div class="footer-left">
        <img src="assets/images/logo.png">
    </div>
    <div class="footer-center">
        <h3>Contact Us</h3>
        <p>+62 819-9763-1414</p>
        <p>happyvalleyrinjani@gmail.com</p>
        <div class="social-icons">
            <img src="assets/icons/gmail.png">
            <img src="assets/icons/ig.png">
            <img src="assets/icons/fb.png">
        </div>
    </div>
    <div class="footer-right">
        <h3>Payment Method</h3>
        <div class="payment-logos">
            <img src="assets/images/payment.png">
        </div>
    </div>
</footer>